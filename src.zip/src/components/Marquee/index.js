import Marquee from './Marquee.vue';

export { Marquee };