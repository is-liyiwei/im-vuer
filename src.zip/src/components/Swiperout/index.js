import Swiperout from './Swiperout.vue';

export { Swiperout };