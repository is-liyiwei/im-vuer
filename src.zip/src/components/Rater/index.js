import Rater from './Rater.vue';

export { Rater };