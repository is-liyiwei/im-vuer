import Indexlist from './Indexlist.vue';

export { Indexlist };