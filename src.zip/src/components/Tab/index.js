import Tab from './Tab.vue';

export { Tab };