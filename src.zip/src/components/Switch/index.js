import Switch from './Switch.vue';

export { Switch };