import Countup from './Countup.vue';

export { Countup };